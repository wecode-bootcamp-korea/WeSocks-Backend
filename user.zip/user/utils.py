import jwt
import json
from wesocks.settings import socks_key
from .models import User
from django.http import JsonResponse, HttpResponse


def login_required(f):
    def wrapper(self, request, *args, **kwargs):
        access_token = request.headers.get('Authorization', None)
        
        if access_token == None:
            return JsonResponse({"message" : "로그인이 필요한 서비스입니다."}, status=401)
        else:
            decode = jwt.decode(access_token, socks_secret,  algorithms=['HS256'])
            user_email = decode["email"]
            user = User.objects.get(emial=user_email)
            request.user = user

            return f(self, request, *args, **kwargs)

    return wrapper





# def login_required(func):

#      def wrapper(self, request, *args, **kwargs):
#         access_token = request.headers.get('Authorization', None)
#         secret = socks_key
#         if access_token:
#             try:
#                 decode = jwt.decode(access_token, socks_key, algorithms=['HS256'])
#                 user_email = decode["email"]
#                 request.user = User.objects.get(email=user_email)
#             except jwt.DecodeError:
#                 return JsonResponse({"error_code" : "INVALID_TOKEN"},status = 401)
#             except User.DoseNotExist:
#                 return JsonResponse({"error_code" : "USER_NOT_FOUND"}, status=401) 
       
#             return func(self, request, *args, **kwargs)
#         else:
#             return JsonResponse({"error_code":"NEED_LOGIN"},status=401)
#         return wrapper


# def user_check(func):
   
#     def wrapper(self, request, *args, **kwargs):
#         access_token = request.headers.get('Authorization', None)
#         secret = socks_key

#         if access_token:  
#             try:          
#                 decode = jwt.decode(access_token, socks_key, algorithms=['HS256'])
#                 user_email = decode["email"]
#                 request.user = User.objects.get(email=user_email)
#             except jwt.DecodeError:
#                 request.user = None
#             except User.DoesNotExist:
#                 request.user = None
#                 return func(self, request, *args, **kwargs)
#         else:
#                 request.user = None
#                 return func(self, request, *args, **kwargs)
#         return wrapper